<?php

$host = "localhost";
$username = "bctajgco_demomd";
$password = "?AwIZL+xYmTx";
$db = "bctajgco_demomd";

$koneksi = mysqli_connect($host, $username, $password, $db) or die("GAGAL");

$base_url = "https://demomd.bermainapi.com/";
date_default_timezone_set('Asia/Jakarta');
