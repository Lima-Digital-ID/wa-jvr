<?
header('content-type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

file_put_contents('whatsapp.txt', '[' . date('Y-m-d H:i:s') . "]\n" . json_encode($data) . "\n\n", FILE_APPEND);
$message = strtolower($data['message']); // ini menangkap pesan masuk
$from = $data['from']; // ini menangkap nomor pengirim pesan
$respon = false;


function sayHello(){
    return ["text" => 'Halloooo! {name} '];
}
function gambar(){
    return [
        'image' => ['url' => 'https://seeklogo.com/images/W/whatsapp-logo-A5A7F17DC1-seeklogo.com.png'],
        'caption' => 'Logo whatsapp!'
    ];
}
function button(){
    
    // maximal 3 button
    $buttons = [
        ['buttonId' => 'id1', 'buttonText' => ['displayText' => 'BUTTON 1'], 'type' => 1], // button 1 // 
        ['buttonId' => 'id2', 'buttonText' => ['displayText' => 'BUTTON 2'], 'type' => 1], // button 2
        ['buttonId' => 'id3', 'buttonText' => ['displayText' => 'BUTTON 3'], 'type' => 1], // button 3
    ];
    $line = "\r\n";
    $pesan = "halo,".$line."ini baris baru";
    $buttonMessage = [
        'text' => $pesan, // pesan utama nya
        'footer' => 'ini pesan footer', // pesan footernya, 
        'buttons' => $buttons,
        'headerType' => 1 // biarkan default
    ];
    return $buttonMessage;
}
function kirim($pesan){
    return ["text" => $pesan];
}



if($message === 'hi'){
    $respon = sayHello();
} else if($message === 'gambar'){
    $respon = gambar();
} else if($message === 'kirim'){
    $respon = kirim("kirim ini aja");
} else if($message === 'btn'){
    $respon = button();
}

echo json_encode($respon);